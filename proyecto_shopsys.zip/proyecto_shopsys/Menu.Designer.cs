﻿namespace proyecto_shopsys
{
    partial class Menu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPRODUCTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTIPOPRODUCTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nCANTIDADDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPRECIOCOMPRADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPRECIOVENTADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMARCADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vINVENTARIOBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.dB_TIENDADataSet = new proyecto_shopsys.DB_TIENDADataSet();
            this.TBSubtotal = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TBCantidad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TBProductos = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBoxDeuda = new System.Windows.Forms.CheckBox();
            this.checkBoxOpCliente = new System.Windows.Forms.CheckBox();
            this.BotónAgregarProducto = new System.Windows.Forms.Button();
            this.numericIDCliente = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numericCantidad = new System.Windows.Forms.NumericUpDown();
            this.numericIDVenta = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.Lcambio = new System.Windows.Forms.Label();
            this.BotónNuevaVenta = new System.Windows.Forms.Button();
            this.BotónFinalizarVenta = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.TBTotal = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.BotónCalcularCambio = new System.Windows.Forms.Button();
            this.TBPagoRecibido = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.BotonAgregarProducto = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.vINVENTARIOBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vINVENTARIOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vINVENTARIOTableAdapter = new proyecto_shopsys.DB_TIENDADataSetTableAdapters.VINVENTARIOTableAdapter();
            this.vINVENTARIOBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dB_TIENDADataSet1 = new proyecto_shopsys.DB_TIENDADataSet();
            this.vINVENTARIOBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.gridInventario = new System.Windows.Forms.DataGridView();
            this.vINVENTARIOBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.cPRODUCTODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nCANTIDADDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPRECIOVENTADataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMARCADataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.BotonBuscar = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.BotónRefrescar = new System.Windows.Forms.Button();
            this.SearchBoxProveedores = new System.Windows.Forms.TextBox();
            this.BotónRefrescarProveedores = new System.Windows.Forms.Button();
            this.BotónBuscarProveedores = new System.Windows.Forms.Button();
            this.gridProveedores = new System.Windows.Forms.DataGridView();
            this.vPROVEEDORESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vPROVEEDORESTableAdapter = new proyecto_shopsys.DB_TIENDADataSetTableAdapters.VPROVEEDORESTableAdapter();
            this.iDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.proveedoresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridClientes = new System.Windows.Forms.DataGridView();
            this.SearchBoxClientes = new System.Windows.Forms.TextBox();
            this.BotónRefrescarCliente = new System.Windows.Forms.Button();
            this.BotónBuscarCliente = new System.Windows.Forms.Button();
            this.tBLVENTASBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBL_VENTASTableAdapter = new proyecto_shopsys.DB_TIENDADataSetTableAdapters.TBL_VENTASTableAdapter();
            this.vCLIENTESBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vCLIENTESTableAdapter = new proyecto_shopsys.DB_TIENDADataSetTableAdapters.VCLIENTESTableAdapter();
            this.label6 = new System.Windows.Forms.Label();
            this.numericIDClienteDeuda = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBoxOpDuedores = new System.Windows.Forms.CheckBox();
            this.TBSubtotalCompra = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TBCantidadCompra = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.TBProductosCompra = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.gridProductoPorProveedor = new System.Windows.Forms.DataGridView();
            this.BotónProductosPorProveedor = new System.Windows.Forms.Button();
            this.numericIDProveedor = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BotónAgregarProductoCompra = new System.Windows.Forms.Button();
            this.numericCantidadCompra = new System.Windows.Forms.NumericUpDown();
            this.numericIDCompra = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.BotónNuevaCompra = new System.Windows.Forms.Button();
            this.BotónFinalizarCompra = new System.Windows.Forms.Button();
            this.BotónCancelarCompra = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.TBTotalCompra = new System.Windows.Forms.TextBox();
            this.BotónCancelarVenta = new System.Windows.Forms.Button();
            this.BotónAgregarClientePersona = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_TIENDADataSet)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericCantidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDVenta)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_TIENDADataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridInventario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridProveedores)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vPROVEEDORESBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLVENTASBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vCLIENTESBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDClienteDeuda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridProductoPorProveedor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDProveedor)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericCantidadCompra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDCompra)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.AccessibleName = "";
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 77);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1077, 600);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.BotónCancelarVenta);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.TBSubtotal);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.TBCantidad);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.TBProductos);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Controls.Add(this.BotónNuevaVenta);
            this.tabPage1.Controls.Add(this.BotónFinalizarVenta);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Controls.Add(this.tableLayoutPanel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1069, 569);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Inicio";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.cPRODUCTODataGridViewTextBoxColumn,
            this.cTIPOPRODUCTODataGridViewTextBoxColumn,
            this.nCANTIDADDataGridViewTextBoxColumn,
            this.cPRECIOCOMPRADataGridViewTextBoxColumn,
            this.cPRECIOVENTADataGridViewTextBoxColumn,
            this.cMARCADataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.vINVENTARIOBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(-1, 17);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(542, 275);
            this.dataGridView1.TabIndex = 24;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cPRODUCTODataGridViewTextBoxColumn
            // 
            this.cPRODUCTODataGridViewTextBoxColumn.DataPropertyName = "CPRODUCTO";
            this.cPRODUCTODataGridViewTextBoxColumn.HeaderText = "Producto";
            this.cPRODUCTODataGridViewTextBoxColumn.Name = "cPRODUCTODataGridViewTextBoxColumn";
            this.cPRODUCTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cTIPOPRODUCTODataGridViewTextBoxColumn
            // 
            this.cTIPOPRODUCTODataGridViewTextBoxColumn.DataPropertyName = "CTIPO_PRODUCTO";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn.HeaderText = "Presentación";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn.Name = "cTIPOPRODUCTODataGridViewTextBoxColumn";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nCANTIDADDataGridViewTextBoxColumn
            // 
            this.nCANTIDADDataGridViewTextBoxColumn.DataPropertyName = "NCANTIDAD";
            this.nCANTIDADDataGridViewTextBoxColumn.HeaderText = "Cantidad";
            this.nCANTIDADDataGridViewTextBoxColumn.Name = "nCANTIDADDataGridViewTextBoxColumn";
            this.nCANTIDADDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cPRECIOCOMPRADataGridViewTextBoxColumn
            // 
            this.cPRECIOCOMPRADataGridViewTextBoxColumn.DataPropertyName = "CPRECIO_COMPRA";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn.HeaderText = "CPRECIO_COMPRA";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn.Name = "cPRECIOCOMPRADataGridViewTextBoxColumn";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn.ReadOnly = true;
            this.cPRECIOCOMPRADataGridViewTextBoxColumn.Visible = false;
            // 
            // cPRECIOVENTADataGridViewTextBoxColumn
            // 
            this.cPRECIOVENTADataGridViewTextBoxColumn.DataPropertyName = "CPRECIO_VENTA";
            this.cPRECIOVENTADataGridViewTextBoxColumn.HeaderText = "Precio";
            this.cPRECIOVENTADataGridViewTextBoxColumn.Name = "cPRECIOVENTADataGridViewTextBoxColumn";
            this.cPRECIOVENTADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cMARCADataGridViewTextBoxColumn
            // 
            this.cMARCADataGridViewTextBoxColumn.DataPropertyName = "CMARCA";
            this.cMARCADataGridViewTextBoxColumn.HeaderText = "CMARCA";
            this.cMARCADataGridViewTextBoxColumn.Name = "cMARCADataGridViewTextBoxColumn";
            this.cMARCADataGridViewTextBoxColumn.ReadOnly = true;
            this.cMARCADataGridViewTextBoxColumn.Visible = false;
            // 
            // vINVENTARIOBindingSource4
            // 
            this.vINVENTARIOBindingSource4.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource4.DataSource = this.dB_TIENDADataSet;
            // 
            // dB_TIENDADataSet
            // 
            this.dB_TIENDADataSet.DataSetName = "DB_TIENDADataSet";
            this.dB_TIENDADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // TBSubtotal
            // 
            this.TBSubtotal.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBSubtotal.Location = new System.Drawing.Point(859, 46);
            this.TBSubtotal.Multiline = true;
            this.TBSubtotal.Name = "TBSubtotal";
            this.TBSubtotal.ReadOnly = true;
            this.TBSubtotal.Size = new System.Drawing.Size(144, 245);
            this.TBSubtotal.TabIndex = 23;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Yellow;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(858, 17);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(2);
            this.label14.Size = new System.Drawing.Size(145, 26);
            this.label14.TabIndex = 22;
            this.label14.Text = "Subtotal";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBCantidad
            // 
            this.TBCantidad.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBCantidad.Location = new System.Drawing.Point(701, 46);
            this.TBCantidad.Multiline = true;
            this.TBCantidad.Name = "TBCantidad";
            this.TBCantidad.ReadOnly = true;
            this.TBCantidad.Size = new System.Drawing.Size(144, 245);
            this.TBCantidad.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Yellow;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(700, 17);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(2);
            this.label11.Size = new System.Drawing.Size(145, 26);
            this.label11.TabIndex = 22;
            this.label11.Text = "Cantidad";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBProductos
            // 
            this.TBProductos.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBProductos.Location = new System.Drawing.Point(547, 46);
            this.TBProductos.Multiline = true;
            this.TBProductos.Name = "TBProductos";
            this.TBProductos.ReadOnly = true;
            this.TBProductos.Size = new System.Drawing.Size(144, 245);
            this.TBProductos.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Yellow;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(547, 17);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(2);
            this.label3.Size = new System.Drawing.Size(145, 26);
            this.label3.TabIndex = 22;
            this.label3.Text = "Productos";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.groupBox3.Controls.Add(this.checkBoxDeuda);
            this.groupBox3.Controls.Add(this.checkBoxOpCliente);
            this.groupBox3.Controls.Add(this.BotónAgregarProducto);
            this.groupBox3.Controls.Add(this.numericIDCliente);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.numericCantidad);
            this.groupBox3.Controls.Add(this.numericIDVenta);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(126, 298);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(788, 119);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Opciones de venta";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // checkBoxDeuda
            // 
            this.checkBoxDeuda.AutoSize = true;
            this.checkBoxDeuda.Enabled = false;
            this.checkBoxDeuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxDeuda.Location = new System.Drawing.Point(456, 49);
            this.checkBoxDeuda.Name = "checkBoxDeuda";
            this.checkBoxDeuda.Size = new System.Drawing.Size(70, 22);
            this.checkBoxDeuda.TabIndex = 30;
            this.checkBoxDeuda.Text = "Deuda";
            this.checkBoxDeuda.UseVisualStyleBackColor = true;
            this.checkBoxDeuda.CheckedChanged += new System.EventHandler(this.checkBoxDeuda_CheckedChanged);
            // 
            // checkBoxOpCliente
            // 
            this.checkBoxOpCliente.AutoSize = true;
            this.checkBoxOpCliente.Enabled = false;
            this.checkBoxOpCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxOpCliente.Location = new System.Drawing.Point(456, 21);
            this.checkBoxOpCliente.Name = "checkBoxOpCliente";
            this.checkBoxOpCliente.Size = new System.Drawing.Size(72, 22);
            this.checkBoxOpCliente.TabIndex = 30;
            this.checkBoxOpCliente.Text = "Cliente";
            this.checkBoxOpCliente.UseVisualStyleBackColor = true;
            this.checkBoxOpCliente.CheckedChanged += new System.EventHandler(this.checkBoxOpCliente_CheckedChanged);
            // 
            // BotónAgregarProducto
            // 
            this.BotónAgregarProducto.Enabled = false;
            this.BotónAgregarProducto.Location = new System.Drawing.Point(614, 80);
            this.BotónAgregarProducto.Name = "BotónAgregarProducto";
            this.BotónAgregarProducto.Size = new System.Drawing.Size(131, 27);
            this.BotónAgregarProducto.TabIndex = 29;
            this.BotónAgregarProducto.Text = "Agregar producto";
            this.BotónAgregarProducto.UseVisualStyleBackColor = true;
            this.BotónAgregarProducto.Click += new System.EventHandler(this.BotónAgregarProducto_Click);
            // 
            // numericIDCliente
            // 
            this.numericIDCliente.Enabled = false;
            this.numericIDCliente.Location = new System.Drawing.Point(437, 80);
            this.numericIDCliente.Name = "numericIDCliente";
            this.numericIDCliente.Size = new System.Drawing.Size(120, 22);
            this.numericIDCliente.TabIndex = 28;
            this.numericIDCliente.ValueChanged += new System.EventHandler(this.numericIDCliente_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(288, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 24);
            this.label13.TabIndex = 27;
            this.label13.Text = "ID cliente";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(287, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(144, 24);
            this.label12.TabIndex = 25;
            this.label12.Text = "Tipo de compra";
            // 
            // numericCantidad
            // 
            this.numericCantidad.Enabled = false;
            this.numericCantidad.Location = new System.Drawing.Point(174, 79);
            this.numericCantidad.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericCantidad.Name = "numericCantidad";
            this.numericCantidad.Size = new System.Drawing.Size(98, 22);
            this.numericCantidad.TabIndex = 24;
            this.numericCantidad.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericIDVenta
            // 
            this.numericIDVenta.Enabled = false;
            this.numericIDVenta.Location = new System.Drawing.Point(174, 32);
            this.numericIDVenta.Name = "numericIDVenta";
            this.numericIDVenta.Size = new System.Drawing.Size(98, 22);
            this.numericIDVenta.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(47, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 24);
            this.label10.TabIndex = 22;
            this.label10.Text = "Cantidad";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(47, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 24);
            this.label9.TabIndex = 21;
            this.label9.Text = "ID producto";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.23634F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.76366F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.Lcambio, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(124, 492);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(790, 23);
            this.tableLayoutPanel2.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Yellow;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(169, 23);
            this.label5.TabIndex = 3;
            this.label5.Text = "CAMBIO";
            // 
            // Lcambio
            // 
            this.Lcambio.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Lcambio.AutoSize = true;
            this.Lcambio.BackColor = System.Drawing.Color.Ivory;
            this.Lcambio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lcambio.Location = new System.Drawing.Point(178, 0);
            this.Lcambio.Name = "Lcambio";
            this.Lcambio.Size = new System.Drawing.Size(609, 23);
            this.Lcambio.TabIndex = 4;
            this.Lcambio.Text = "$0.00";
            // 
            // BotónNuevaVenta
            // 
            this.BotónNuevaVenta.Location = new System.Drawing.Point(418, 532);
            this.BotónNuevaVenta.Name = "BotónNuevaVenta";
            this.BotónNuevaVenta.Size = new System.Drawing.Size(171, 28);
            this.BotónNuevaVenta.TabIndex = 13;
            this.BotónNuevaVenta.Text = "Nueva Venta";
            this.BotónNuevaVenta.UseVisualStyleBackColor = true;
            this.BotónNuevaVenta.Click += new System.EventHandler(this.BotónNuevaCompra_Click);
            // 
            // BotónFinalizarVenta
            // 
            this.BotónFinalizarVenta.Enabled = false;
            this.BotónFinalizarVenta.Location = new System.Drawing.Point(742, 532);
            this.BotónFinalizarVenta.Name = "BotónFinalizarVenta";
            this.BotónFinalizarVenta.Size = new System.Drawing.Size(172, 28);
            this.BotónFinalizarVenta.TabIndex = 12;
            this.BotónFinalizarVenta.Text = "Registrar Venta";
            this.BotónFinalizarVenta.UseVisualStyleBackColor = true;
            this.BotónFinalizarVenta.Click += new System.EventHandler(this.BotónFinalizarCompra_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.05323F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.94677F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.TBTotal, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(124, 423);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(789, 25);
            this.tableLayoutPanel1.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "TOTAL";
            // 
            // TBTotal
            // 
            this.TBTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBTotal.AutoSize = true;
            this.TBTotal.BackColor = System.Drawing.Color.Ivory;
            this.TBTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBTotal.Location = new System.Drawing.Point(176, 0);
            this.TBTotal.Name = "TBTotal";
            this.TBTotal.Size = new System.Drawing.Size(610, 25);
            this.TBTotal.TabIndex = 1;
            this.TBTotal.Text = "$0.00";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.35817F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 74.64183F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102F));
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.BotónCalcularCambio, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.TBPagoRecibido, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(123, 454);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(791, 35);
            this.tableLayoutPanel3.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Yellow;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 35);
            this.label4.TabIndex = 2;
            this.label4.Text = "TOTAL RECIBIDO";
            // 
            // BotónCalcularCambio
            // 
            this.BotónCalcularCambio.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BotónCalcularCambio.Enabled = false;
            this.BotónCalcularCambio.Location = new System.Drawing.Point(691, 3);
            this.BotónCalcularCambio.Name = "BotónCalcularCambio";
            this.BotónCalcularCambio.Size = new System.Drawing.Size(97, 29);
            this.BotónCalcularCambio.TabIndex = 9;
            this.BotónCalcularCambio.Text = "Calcular";
            this.BotónCalcularCambio.UseVisualStyleBackColor = true;
            this.BotónCalcularCambio.Click += new System.EventHandler(this.button1_Click);
            // 
            // TBPagoRecibido
            // 
            this.TBPagoRecibido.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TBPagoRecibido.Enabled = false;
            this.TBPagoRecibido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBPagoRecibido.Location = new System.Drawing.Point(177, 3);
            this.TBPagoRecibido.Name = "TBPagoRecibido";
            this.TBPagoRecibido.Size = new System.Drawing.Size(508, 26);
            this.TBPagoRecibido.TabIndex = 5;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.SearchBox);
            this.tabPage2.Controls.Add(this.BotónRefrescar);
            this.tabPage2.Controls.Add(this.BotonBuscar);
            this.tabPage2.Controls.Add(this.gridInventario);
            this.tabPage2.Controls.Add(this.BotonAgregarProducto);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1069, 569);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Inventario";
            // 
            // BotonAgregarProducto
            // 
            this.BotonAgregarProducto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BotonAgregarProducto.Location = new System.Drawing.Point(819, 3);
            this.BotonAgregarProducto.Name = "BotonAgregarProducto";
            this.BotonAgregarProducto.Size = new System.Drawing.Size(242, 33);
            this.BotonAgregarProducto.TabIndex = 1;
            this.BotonAgregarProducto.Text = "Añadir Producto";
            this.BotonAgregarProducto.UseVisualStyleBackColor = true;
            this.BotonAgregarProducto.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.TBTotalCompra);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.BotónCancelarCompra);
            this.tabPage3.Controls.Add(this.BotónNuevaCompra);
            this.tabPage3.Controls.Add(this.BotónFinalizarCompra);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.numericIDProveedor);
            this.tabPage3.Controls.Add(this.gridProductoPorProveedor);
            this.tabPage3.Controls.Add(this.BotónProductosPorProveedor);
            this.tabPage3.Controls.Add(this.TBSubtotalCompra);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.TBCantidadCompra);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.TBProductosCompra);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.gridProveedores);
            this.tabPage3.Controls.Add(this.SearchBoxProveedores);
            this.tabPage3.Controls.Add(this.BotónRefrescarProveedores);
            this.tabPage3.Controls.Add(this.BotónBuscarProveedores);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1069, 569);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Proveedores";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(611, 567);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(173, 33);
            this.button5.TabIndex = 1;
            this.button5.Text = "Agregar a inventario";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.checkBoxOpDuedores);
            this.tabPage4.Controls.Add(this.gridClientes);
            this.tabPage4.Controls.Add(this.SearchBoxClientes);
            this.tabPage4.Controls.Add(this.BotónRefrescarCliente);
            this.tabPage4.Controls.Add(this.BotónBuscarCliente);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1069, 569);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Clientes y Deudas";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.Window;
            this.groupBox1.Controls.Add(this.numericIDClienteDeuda);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Location = new System.Drawing.Point(259, 299);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(557, 220);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Consultar deuda";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightGreen;
            this.button6.Location = new System.Drawing.Point(411, 166);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(103, 37);
            this.button6.TabIndex = 1;
            this.button6.Text = "Consultar";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.BotónDeudaCliente_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.27844F));
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(51, 93);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(108, 45);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightGreen;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 45);
            this.label7.TabIndex = 0;
            this.label7.Text = "ID";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.LightGreen;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1069, 569);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Ventas";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(97, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 41);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tienda San Juan Diego";
            // 
            // vINVENTARIOBindingSource1
            // 
            this.vINVENTARIOBindingSource1.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource1.DataSource = this.dB_TIENDADataSet;
            // 
            // vINVENTARIOBindingSource
            // 
            this.vINVENTARIOBindingSource.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource.DataSource = this.dB_TIENDADataSet;
            // 
            // vINVENTARIOTableAdapter
            // 
            this.vINVENTARIOTableAdapter.ClearBeforeFill = true;
            // 
            // vINVENTARIOBindingSource2
            // 
            this.vINVENTARIOBindingSource2.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource2.DataSource = this.dB_TIENDADataSet;
            // 
            // dB_TIENDADataSet1
            // 
            this.dB_TIENDADataSet1.DataSetName = "DB_TIENDADataSet";
            this.dB_TIENDADataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vINVENTARIOBindingSource3
            // 
            this.vINVENTARIOBindingSource3.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource3.DataSource = this.dB_TIENDADataSet1;
            // 
            // gridInventario
            // 
            this.gridInventario.AllowUserToAddRows = false;
            this.gridInventario.AllowUserToDeleteRows = false;
            this.gridInventario.AutoGenerateColumns = false;
            this.gridInventario.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridInventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridInventario.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cPRODUCTODataGridViewTextBoxColumn1,
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1,
            this.nCANTIDADDataGridViewTextBoxColumn1,
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1,
            this.cPRECIOVENTADataGridViewTextBoxColumn1,
            this.cMARCADataGridViewTextBoxColumn1,
            this.iDDataGridViewTextBoxColumn1});
            this.gridInventario.DataSource = this.vINVENTARIOBindingSource5;
            this.gridInventario.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gridInventario.Location = new System.Drawing.Point(3, 38);
            this.gridInventario.Name = "gridInventario";
            this.gridInventario.ReadOnly = true;
            this.gridInventario.Size = new System.Drawing.Size(1061, 526);
            this.gridInventario.TabIndex = 2;
            // 
            // vINVENTARIOBindingSource5
            // 
            this.vINVENTARIOBindingSource5.DataMember = "VINVENTARIO";
            this.vINVENTARIOBindingSource5.DataSource = this.dB_TIENDADataSet;
            // 
            // cPRODUCTODataGridViewTextBoxColumn1
            // 
            this.cPRODUCTODataGridViewTextBoxColumn1.DataPropertyName = "CPRODUCTO";
            this.cPRODUCTODataGridViewTextBoxColumn1.HeaderText = "Producto";
            this.cPRODUCTODataGridViewTextBoxColumn1.Name = "cPRODUCTODataGridViewTextBoxColumn1";
            this.cPRODUCTODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cTIPOPRODUCTODataGridViewTextBoxColumn1
            // 
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1.DataPropertyName = "CTIPO_PRODUCTO";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1.HeaderText = "Presentación";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1.Name = "cTIPOPRODUCTODataGridViewTextBoxColumn1";
            this.cTIPOPRODUCTODataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nCANTIDADDataGridViewTextBoxColumn1
            // 
            this.nCANTIDADDataGridViewTextBoxColumn1.DataPropertyName = "NCANTIDAD";
            this.nCANTIDADDataGridViewTextBoxColumn1.HeaderText = "Cantidad";
            this.nCANTIDADDataGridViewTextBoxColumn1.Name = "nCANTIDADDataGridViewTextBoxColumn1";
            this.nCANTIDADDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cPRECIOCOMPRADataGridViewTextBoxColumn1
            // 
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1.DataPropertyName = "CPRECIO_COMPRA";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1.HeaderText = "PrecioCompra";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1.Name = "cPRECIOCOMPRADataGridViewTextBoxColumn1";
            this.cPRECIOCOMPRADataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cPRECIOVENTADataGridViewTextBoxColumn1
            // 
            this.cPRECIOVENTADataGridViewTextBoxColumn1.DataPropertyName = "CPRECIO_VENTA";
            this.cPRECIOVENTADataGridViewTextBoxColumn1.HeaderText = "PrecioVenta";
            this.cPRECIOVENTADataGridViewTextBoxColumn1.Name = "cPRECIOVENTADataGridViewTextBoxColumn1";
            this.cPRECIOVENTADataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // cMARCADataGridViewTextBoxColumn1
            // 
            this.cMARCADataGridViewTextBoxColumn1.DataPropertyName = "CMARCA";
            this.cMARCADataGridViewTextBoxColumn1.HeaderText = "Marca";
            this.cMARCADataGridViewTextBoxColumn1.Name = "cMARCADataGridViewTextBoxColumn1";
            this.cMARCADataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            this.iDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // SearchBox
            // 
            this.SearchBox.Location = new System.Drawing.Point(6, 6);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(193, 24);
            this.SearchBox.TabIndex = 3;
            this.SearchBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BotonBuscar
            // 
            this.BotonBuscar.Location = new System.Drawing.Point(205, 3);
            this.BotonBuscar.Name = "BotonBuscar";
            this.BotonBuscar.Size = new System.Drawing.Size(100, 29);
            this.BotonBuscar.TabIndex = 1;
            this.BotonBuscar.Text = "Buscar";
            this.BotonBuscar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotonBuscar.UseVisualStyleBackColor = true;
            this.BotonBuscar.Click += new System.EventHandler(this.BotonBuscar_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(-517, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 24);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BotónRefrescar
            // 
            this.BotónRefrescar.Location = new System.Drawing.Point(311, 3);
            this.BotónRefrescar.Name = "BotónRefrescar";
            this.BotónRefrescar.Size = new System.Drawing.Size(100, 29);
            this.BotónRefrescar.TabIndex = 1;
            this.BotónRefrescar.Text = "Refrescar";
            this.BotónRefrescar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónRefrescar.UseVisualStyleBackColor = true;
            this.BotónRefrescar.Click += new System.EventHandler(this.BotónRefrescar_Click);
            // 
            // SearchBoxProveedores
            // 
            this.SearchBoxProveedores.Location = new System.Drawing.Point(6, 6);
            this.SearchBoxProveedores.Name = "SearchBoxProveedores";
            this.SearchBoxProveedores.Size = new System.Drawing.Size(342, 24);
            this.SearchBoxProveedores.TabIndex = 6;
            // 
            // BotónRefrescarProveedores
            // 
            this.BotónRefrescarProveedores.Location = new System.Drawing.Point(501, 5);
            this.BotónRefrescarProveedores.Name = "BotónRefrescarProveedores";
            this.BotónRefrescarProveedores.Size = new System.Drawing.Size(143, 29);
            this.BotónRefrescarProveedores.TabIndex = 4;
            this.BotónRefrescarProveedores.Text = "Refrescar";
            this.BotónRefrescarProveedores.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónRefrescarProveedores.UseVisualStyleBackColor = true;
            this.BotónRefrescarProveedores.Click += new System.EventHandler(this.BotónRefrescarProveedores_Click);
            // 
            // BotónBuscarProveedores
            // 
            this.BotónBuscarProveedores.Location = new System.Drawing.Point(354, 5);
            this.BotónBuscarProveedores.Name = "BotónBuscarProveedores";
            this.BotónBuscarProveedores.Size = new System.Drawing.Size(143, 29);
            this.BotónBuscarProveedores.TabIndex = 5;
            this.BotónBuscarProveedores.Text = "Buscar";
            this.BotónBuscarProveedores.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónBuscarProveedores.UseVisualStyleBackColor = true;
            this.BotónBuscarProveedores.Click += new System.EventHandler(this.BotónBuscarProveedores_Click);
            // 
            // gridProveedores
            // 
            this.gridProveedores.AllowUserToAddRows = false;
            this.gridProveedores.AllowUserToDeleteRows = false;
            this.gridProveedores.AutoGenerateColumns = false;
            this.gridProveedores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridProveedores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridProveedores.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn2,
            this.proveedoresDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn});
            this.gridProveedores.DataSource = this.vPROVEEDORESBindingSource;
            this.gridProveedores.Location = new System.Drawing.Point(6, 37);
            this.gridProveedores.Name = "gridProveedores";
            this.gridProveedores.ReadOnly = true;
            this.gridProveedores.Size = new System.Drawing.Size(638, 242);
            this.gridProveedores.TabIndex = 7;
            // 
            // vPROVEEDORESBindingSource
            // 
            this.vPROVEEDORESBindingSource.DataMember = "VPROVEEDORES";
            this.vPROVEEDORESBindingSource.DataSource = this.dB_TIENDADataSet;
            // 
            // vPROVEEDORESTableAdapter
            // 
            this.vPROVEEDORESTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn2
            // 
            this.iDDataGridViewTextBoxColumn2.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn2.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn2.Name = "iDDataGridViewTextBoxColumn2";
            this.iDDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // proveedoresDataGridViewTextBoxColumn
            // 
            this.proveedoresDataGridViewTextBoxColumn.DataPropertyName = "Proveedores";
            this.proveedoresDataGridViewTextBoxColumn.HeaderText = "Proveedores";
            this.proveedoresDataGridViewTextBoxColumn.Name = "proveedoresDataGridViewTextBoxColumn";
            this.proveedoresDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            this.telefonoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // gridClientes
            // 
            this.gridClientes.AllowUserToAddRows = false;
            this.gridClientes.AllowUserToDeleteRows = false;
            this.gridClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridClientes.Location = new System.Drawing.Point(134, 44);
            this.gridClientes.Name = "gridClientes";
            this.gridClientes.ReadOnly = true;
            this.gridClientes.Size = new System.Drawing.Size(797, 228);
            this.gridClientes.TabIndex = 11;
            // 
            // SearchBoxClientes
            // 
            this.SearchBoxClientes.Location = new System.Drawing.Point(134, 14);
            this.SearchBoxClientes.Name = "SearchBoxClientes";
            this.SearchBoxClientes.Size = new System.Drawing.Size(298, 24);
            this.SearchBoxClientes.TabIndex = 10;
            // 
            // BotónRefrescarCliente
            // 
            this.BotónRefrescarCliente.Location = new System.Drawing.Point(781, 12);
            this.BotónRefrescarCliente.Name = "BotónRefrescarCliente";
            this.BotónRefrescarCliente.Size = new System.Drawing.Size(150, 29);
            this.BotónRefrescarCliente.TabIndex = 8;
            this.BotónRefrescarCliente.Text = "Refrescar";
            this.BotónRefrescarCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónRefrescarCliente.UseVisualStyleBackColor = true;
            this.BotónRefrescarCliente.Click += new System.EventHandler(this.BotónRefrescarCliente_Click);
            // 
            // BotónBuscarCliente
            // 
            this.BotónBuscarCliente.Location = new System.Drawing.Point(616, 13);
            this.BotónBuscarCliente.Name = "BotónBuscarCliente";
            this.BotónBuscarCliente.Size = new System.Drawing.Size(150, 29);
            this.BotónBuscarCliente.TabIndex = 9;
            this.BotónBuscarCliente.Text = "Buscar";
            this.BotónBuscarCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónBuscarCliente.UseVisualStyleBackColor = true;
            this.BotónBuscarCliente.Click += new System.EventHandler(this.BotónBuscarCliente_Click);
            // 
            // tBLVENTASBindingSource
            // 
            this.tBLVENTASBindingSource.DataMember = "TBL_VENTAS";
            this.tBLVENTASBindingSource.DataSource = this.dB_TIENDADataSet;
            // 
            // tBL_VENTASTableAdapter
            // 
            this.tBL_VENTASTableAdapter.ClearBeforeFill = true;
            // 
            // vCLIENTESBindingSource
            // 
            this.vCLIENTESBindingSource.DataMember = "VCLIENTES";
            this.vCLIENTESBindingSource.DataSource = this.dB_TIENDADataSet;
            // 
            // vCLIENTESTableAdapter
            // 
            this.vCLIENTESTableAdapter.ClearBeforeFill = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(122, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(324, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ver deuda desglosada del cliente";
            // 
            // numericIDClienteDeuda
            // 
            this.numericIDClienteDeuda.Location = new System.Drawing.Point(169, 103);
            this.numericIDClienteDeuda.Name = "numericIDClienteDeuda";
            this.numericIDClienteDeuda.Size = new System.Drawing.Size(358, 24);
            this.numericIDClienteDeuda.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::proyecto_shopsys.Properties.Resources.índice;
            this.pictureBox1.Location = new System.Drawing.Point(8, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // checkBoxOpDuedores
            // 
            this.checkBoxOpDuedores.AutoSize = true;
            this.checkBoxOpDuedores.Location = new System.Drawing.Point(454, 16);
            this.checkBoxOpDuedores.Name = "checkBoxOpDuedores";
            this.checkBoxOpDuedores.Size = new System.Drawing.Size(127, 22);
            this.checkBoxOpDuedores.TabIndex = 12;
            this.checkBoxOpDuedores.Text = "Solo Deudores";
            this.checkBoxOpDuedores.UseVisualStyleBackColor = true;
            // 
            // TBSubtotalCompra
            // 
            this.TBSubtotalCompra.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBSubtotalCompra.Location = new System.Drawing.Point(956, 36);
            this.TBSubtotalCompra.Multiline = true;
            this.TBSubtotalCompra.Name = "TBSubtotalCompra";
            this.TBSubtotalCompra.ReadOnly = true;
            this.TBSubtotalCompra.Size = new System.Drawing.Size(80, 246);
            this.TBSubtotalCompra.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Yellow;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(955, 7);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(2);
            this.label8.Size = new System.Drawing.Size(81, 27);
            this.label8.TabIndex = 24;
            this.label8.Text = "Subtotal";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBCantidadCompra
            // 
            this.TBCantidadCompra.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBCantidadCompra.Location = new System.Drawing.Point(870, 36);
            this.TBCantidadCompra.Multiline = true;
            this.TBCantidadCompra.Name = "TBCantidadCompra";
            this.TBCantidadCompra.ReadOnly = true;
            this.TBCantidadCompra.Size = new System.Drawing.Size(80, 246);
            this.TBCantidadCompra.TabIndex = 28;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Yellow;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(869, 7);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(2);
            this.label15.Size = new System.Drawing.Size(81, 27);
            this.label15.TabIndex = 25;
            this.label15.Text = "Cantidad";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBProductosCompra
            // 
            this.TBProductosCompra.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBProductosCompra.Location = new System.Drawing.Point(730, 36);
            this.TBProductosCompra.Multiline = true;
            this.TBProductosCompra.Name = "TBProductosCompra";
            this.TBProductosCompra.ReadOnly = true;
            this.TBProductosCompra.Size = new System.Drawing.Size(134, 246);
            this.TBProductosCompra.TabIndex = 29;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Yellow;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(730, 7);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(2);
            this.label16.Size = new System.Drawing.Size(135, 27);
            this.label16.TabIndex = 26;
            this.label16.Text = "Productos";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gridProductoPorProveedor
            // 
            this.gridProductoPorProveedor.AllowUserToAddRows = false;
            this.gridProductoPorProveedor.AllowUserToDeleteRows = false;
            this.gridProductoPorProveedor.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridProductoPorProveedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridProductoPorProveedor.Location = new System.Drawing.Point(7, 320);
            this.gridProductoPorProveedor.Name = "gridProductoPorProveedor";
            this.gridProductoPorProveedor.ReadOnly = true;
            this.gridProductoPorProveedor.Size = new System.Drawing.Size(638, 240);
            this.gridProductoPorProveedor.TabIndex = 33;
            // 
            // BotónProductosPorProveedor
            // 
            this.BotónProductosPorProveedor.Location = new System.Drawing.Point(527, 285);
            this.BotónProductosPorProveedor.Name = "BotónProductosPorProveedor";
            this.BotónProductosPorProveedor.Size = new System.Drawing.Size(117, 29);
            this.BotónProductosPorProveedor.TabIndex = 31;
            this.BotónProductosPorProveedor.Text = "Buscar";
            this.BotónProductosPorProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BotónProductosPorProveedor.UseVisualStyleBackColor = true;
            this.BotónProductosPorProveedor.Click += new System.EventHandler(this.BotónProductosPorProveedor_Click);
            // 
            // numericIDProveedor
            // 
            this.numericIDProveedor.Location = new System.Drawing.Point(434, 287);
            this.numericIDProveedor.Name = "numericIDProveedor";
            this.numericIDProveedor.Size = new System.Drawing.Size(87, 24);
            this.numericIDProveedor.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(8, 289);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(424, 20);
            this.label17.TabIndex = 35;
            this.label17.Text = "Buscar Productos del Proveedor. Ingrese ID del Proveedor:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.groupBox2.Controls.Add(this.BotónAgregarProductoCompra);
            this.groupBox2.Controls.Add(this.numericCantidadCompra);
            this.groupBox2.Controls.Add(this.numericIDCompra);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(730, 353);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(306, 148);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Opciones de venta";
            // 
            // BotónAgregarProductoCompra
            // 
            this.BotónAgregarProductoCompra.Enabled = false;
            this.BotónAgregarProductoCompra.Location = new System.Drawing.Point(133, 107);
            this.BotónAgregarProductoCompra.Name = "BotónAgregarProductoCompra";
            this.BotónAgregarProductoCompra.Size = new System.Drawing.Size(167, 27);
            this.BotónAgregarProductoCompra.TabIndex = 29;
            this.BotónAgregarProductoCompra.Text = "Agregar producto";
            this.BotónAgregarProductoCompra.UseVisualStyleBackColor = true;
            this.BotónAgregarProductoCompra.Click += new System.EventHandler(this.BotónAgregarProductoCompra_Click);
            // 
            // numericCantidadCompra
            // 
            this.numericCantidadCompra.Enabled = false;
            this.numericCantidadCompra.Location = new System.Drawing.Point(133, 79);
            this.numericCantidadCompra.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericCantidadCompra.Name = "numericCantidadCompra";
            this.numericCantidadCompra.Size = new System.Drawing.Size(167, 22);
            this.numericCantidadCompra.TabIndex = 24;
            this.numericCantidadCompra.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericIDCompra
            // 
            this.numericIDCompra.Enabled = false;
            this.numericIDCompra.Location = new System.Drawing.Point(133, 32);
            this.numericIDCompra.Name = "numericIDCompra";
            this.numericIDCompra.Size = new System.Drawing.Size(167, 22);
            this.numericIDCompra.TabIndex = 23;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 77);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 24);
            this.label22.TabIndex = 22;
            this.label22.Text = "Cantidad";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 32);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(107, 24);
            this.label23.TabIndex = 21;
            this.label23.Text = "ID producto";
            // 
            // BotónNuevaCompra
            // 
            this.BotónNuevaCompra.Location = new System.Drawing.Point(810, 533);
            this.BotónNuevaCompra.Name = "BotónNuevaCompra";
            this.BotónNuevaCompra.Size = new System.Drawing.Size(122, 28);
            this.BotónNuevaCompra.TabIndex = 40;
            this.BotónNuevaCompra.Text = "Nueva Compra";
            this.BotónNuevaCompra.UseVisualStyleBackColor = true;
            this.BotónNuevaCompra.Click += new System.EventHandler(this.BotónNuevaCompra_Click_1);
            // 
            // BotónFinalizarCompra
            // 
            this.BotónFinalizarCompra.Enabled = false;
            this.BotónFinalizarCompra.Location = new System.Drawing.Point(938, 533);
            this.BotónFinalizarCompra.Name = "BotónFinalizarCompra";
            this.BotónFinalizarCompra.Size = new System.Drawing.Size(123, 28);
            this.BotónFinalizarCompra.TabIndex = 39;
            this.BotónFinalizarCompra.Text = "Registrar Compra";
            this.BotónFinalizarCompra.UseVisualStyleBackColor = true;
            this.BotónFinalizarCompra.Click += new System.EventHandler(this.BotónFinalizarCompra_Click_1);
            // 
            // BotónCancelarCompra
            // 
            this.BotónCancelarCompra.Enabled = false;
            this.BotónCancelarCompra.Location = new System.Drawing.Point(682, 532);
            this.BotónCancelarCompra.Name = "BotónCancelarCompra";
            this.BotónCancelarCompra.Size = new System.Drawing.Size(122, 28);
            this.BotónCancelarCompra.TabIndex = 40;
            this.BotónCancelarCompra.Text = "Cancelar";
            this.BotónCancelarCompra.UseVisualStyleBackColor = true;
            this.BotónCancelarCompra.Click += new System.EventHandler(this.BotónCancelarCompra_Click);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Yellow;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(730, 300);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(2);
            this.label18.Size = new System.Drawing.Size(81, 27);
            this.label18.TabIndex = 41;
            this.label18.Text = "Total";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBTotalCompra
            // 
            this.TBTotalCompra.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TBTotalCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBTotalCompra.Location = new System.Drawing.Point(825, 300);
            this.TBTotalCompra.Multiline = true;
            this.TBTotalCompra.Name = "TBTotalCompra";
            this.TBTotalCompra.ReadOnly = true;
            this.TBTotalCompra.Size = new System.Drawing.Size(211, 27);
            this.TBTotalCompra.TabIndex = 42;
            this.TBTotalCompra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BotónCancelarVenta
            // 
            this.BotónCancelarVenta.Enabled = false;
            this.BotónCancelarVenta.Location = new System.Drawing.Point(127, 532);
            this.BotónCancelarVenta.Name = "BotónCancelarVenta";
            this.BotónCancelarVenta.Size = new System.Drawing.Size(172, 28);
            this.BotónCancelarVenta.TabIndex = 41;
            this.BotónCancelarVenta.Text = "Cancelar";
            this.BotónCancelarVenta.UseVisualStyleBackColor = true;
            this.BotónCancelarVenta.Click += new System.EventHandler(this.BotónCancelarVenta_Click);
            // 
            // BotónAgregarClientePersona
            // 
            this.BotónAgregarClientePersona.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotónAgregarClientePersona.Location = new System.Drawing.Point(848, 12);
            this.BotónAgregarClientePersona.Name = "BotónAgregarClientePersona";
            this.BotónAgregarClientePersona.Size = new System.Drawing.Size(229, 59);
            this.BotónAgregarClientePersona.TabIndex = 5;
            this.BotónAgregarClientePersona.Text = "Agregar Cliente / Proveedor";
            this.BotónAgregarClientePersona.UseVisualStyleBackColor = true;
            this.BotónAgregarClientePersona.Click += new System.EventHandler(this.BotónAgregarClientePersona_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(1077, 677);
            this.Controls.Add(this.BotónAgregarClientePersona);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Syshop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_TIENDADataSet)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericCantidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDVenta)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dB_TIENDADataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridInventario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vINVENTARIOBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridProveedores)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vPROVEEDORESBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLVENTASBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vCLIENTESBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDClienteDeuda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridProductoPorProveedor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDProveedor)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericCantidadCompra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericIDCompra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button BotonAgregarProducto;
        private System.Windows.Forms.Button BotónCalcularCambio;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Lcambio;
        private System.Windows.Forms.TextBox TBPagoRecibido;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button BotónNuevaVenta;
        private System.Windows.Forms.Button BotónFinalizarVenta;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label TBTotal;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numericCantidad;
        private System.Windows.Forms.NumericUpDown numericIDVenta;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button BotónAgregarProducto;
        private System.Windows.Forms.NumericUpDown numericIDCliente;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TBProductos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxDeuda;
        private System.Windows.Forms.CheckBox checkBoxOpCliente;
        private System.Windows.Forms.TextBox TBSubtotal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TBCantidad;
        private System.Windows.Forms.Label label11;
        private DB_TIENDADataSet dB_TIENDADataSet;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource;
        private DB_TIENDADataSetTableAdapters.VINVENTARIOTableAdapter vINVENTARIOTableAdapter;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource1;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource2;
        private DB_TIENDADataSet dB_TIENDADataSet1;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRODUCTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTIPOPRODUCTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nCANTIDADDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRECIOCOMPRADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRECIOVENTADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMARCADataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource4;
        private System.Windows.Forms.DataGridView gridInventario;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRODUCTODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTIPOPRODUCTODataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nCANTIDADDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRECIOCOMPRADataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPRECIOVENTADataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMARCADataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource vINVENTARIOBindingSource5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Button BotonBuscar;
        private System.Windows.Forms.Button BotónRefrescar;
        private System.Windows.Forms.DataGridView gridProveedores;
        private System.Windows.Forms.TextBox SearchBoxProveedores;
        private System.Windows.Forms.Button BotónRefrescarProveedores;
        private System.Windows.Forms.Button BotónBuscarProveedores;
        private System.Windows.Forms.BindingSource vPROVEEDORESBindingSource;
        private DB_TIENDADataSetTableAdapters.VPROVEEDORESTableAdapter vPROVEEDORESTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn proveedoresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView gridClientes;
        private System.Windows.Forms.TextBox SearchBoxClientes;
        private System.Windows.Forms.Button BotónRefrescarCliente;
        private System.Windows.Forms.Button BotónBuscarCliente;
        private System.Windows.Forms.BindingSource tBLVENTASBindingSource;
        private DB_TIENDADataSetTableAdapters.TBL_VENTASTableAdapter tBL_VENTASTableAdapter;
        private System.Windows.Forms.BindingSource vCLIENTESBindingSource;
        private DB_TIENDADataSetTableAdapters.VCLIENTESTableAdapter vCLIENTESTableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericIDClienteDeuda;
        private System.Windows.Forms.CheckBox checkBoxOpDuedores;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown numericIDProveedor;
        private System.Windows.Forms.DataGridView gridProductoPorProveedor;
        private System.Windows.Forms.Button BotónProductosPorProveedor;
        private System.Windows.Forms.TextBox TBSubtotalCompra;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TBCantidadCompra;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox TBProductosCompra;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BotónAgregarProductoCompra;
        private System.Windows.Forms.NumericUpDown numericCantidadCompra;
        private System.Windows.Forms.NumericUpDown numericIDCompra;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button BotónNuevaCompra;
        private System.Windows.Forms.Button BotónFinalizarCompra;
        private System.Windows.Forms.Button BotónCancelarCompra;
        private System.Windows.Forms.TextBox TBTotalCompra;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button BotónCancelarVenta;
        private System.Windows.Forms.Button BotónAgregarClientePersona;
    }
}

